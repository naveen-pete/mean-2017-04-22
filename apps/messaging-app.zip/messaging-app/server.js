// Get dependencies
var express = require('express');
var path = require('path');
var http = require('http');
var bodyParser = require('body-parser');
var logger = require('morgan');
var mongoose = require('mongoose');

// Get our API routes
var appRoutes = require('./server/routes/app');
var messageRoutes = require('./server/routes/message');
var userRoutes = require('./server/routes/user');

var app = express();

// Connect to database
mongoose.connect('mongodb://localhost:27017/messenger');
var db = mongoose.connection;

db.on('error', function() {
  console.error('Error connecting to database server.');
});

db.once('open', function() {
    console.log('Successfully connected to database server');
});

// Set up logger
app.use(logger('dev'));

// Parsers for POST data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Point static path to dist
app.use(express.static(path.join(__dirname, 'dist')));

// Set our app routes
app.use('/message', messageRoutes);
app.use('/user', userRoutes);
app.use('/', appRoutes);

// Catch all other routes and return the index file
app.use(function(req, res, next) {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
});

/**
 * Get port from environment and store in Express.
 */
var port = 3000;
app.set('port', port);

/**
 * Create HTTP server.
 */
var server = http.createServer(app);

/**
 * Listen on provided port, on all network interfaces.
 */
server.listen(port, function() {
  console.log(`Messenger App running on localhost:${port}`);
});
