import { MessagingAppPage } from './app.po';

describe('messaging-app App', () => {
  let page: MessagingAppPage;

  beforeEach(() => {
    page = new MessagingAppPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
